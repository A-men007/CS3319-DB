Source Code: http://nodejs.org/dist/__VERSION__/node-__VERSION__.tar.gz

Macintosh Installer (Universal): http://nodejs.org/dist/__VERSION__/node-__VERSION__.pkg

Windows Installer: http://nodejs.org/dist/__VERSION__/node-__VERSION__-x86.msi

Windows x64 Installer: http://nodejs.org/dist/__VERSION__/x64/node-__VERSION__-x64.msi

Windows x64 Files: http://nodejs.org/dist/__VERSION__/x64/

Other release files: http://nodejs.org/dist/__VERSION__/

Website: http://nodejs.org/docs/__VERSION__/

Documentation: http://nodejs.org/docs/__VERSION__/api/
