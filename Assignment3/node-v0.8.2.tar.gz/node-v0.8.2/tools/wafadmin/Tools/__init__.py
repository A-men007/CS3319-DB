#!/usr/bin/env python
# encoding: utf-8
# Thomas Nagy, 2006 (ita)

